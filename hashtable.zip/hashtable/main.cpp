#include <iostream>
#include "hash_table.h"

using namespace std;

int main(){

    HashTable ht(10);

    ht.insert(10,20);
    ht.insert(25,50);
    ht.insert(37,90);

    ht.insert("fg",67);
    ht.insert("abc",12);

    ht.print();

    return 0;
}
