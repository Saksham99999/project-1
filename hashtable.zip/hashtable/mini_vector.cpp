#include <iostream>
#include "mini_vector.h"


mini_vector::mini_vector(): _size(0), _capacity(1){
  _data = new int[_capacity];

}

mini_vector::mini_vector(size_t size): _size(size), _capacity(size*2){
  _data = new int[_capacity];
}

mini_vector::mini_vector(int *data, size_t size): _size(size), _capacity(2*size){
  _data = new int[_capacity];
  for(int i=0; i<size; i++){
    *(_data + i) = *(data + i);
  }
}

mini_vector::mini_vector(int *data, size_t size, size_t capacity): _size(size), _capacity(capacity){
  if(size > capacity){
    std ::cout << " Constructor : Error size cannot be greater than capacity!!!" << std :: endl;
    return;
  }
  _data = new int[_capacity];
  for(int i=0; i<size; i++){
    *(_data + i) = *(data + i);
  }
}

mini_vector::~mini_vector(){
  delete[] _data;
}

mini_vector::mini_vector(const mini_vector& other){
  this->_size = other._size;
  this->_capacity= other._capacity;
  this->_data = nullptr;
  this->_data = new int[_capacity];
  for(int i=0; i<_size; i++){
    *(_data + i) = *(other._data + i);
  }
}

mini_vector& mini_vector::operator=(const mini_vector& other){
  if(this == &other){return *this;}
  this->_size = other._size;
  this->_capacity= other._capacity;
  this->_data = nullptr;
  this->_data = new int[_capacity];
  for(int i=0; i<_size; i++){
    *(_data + i) = *(other._data + i);
  }
  return *this;
}

bool mini_vector::resize(){
  if(_capacity == 0) { _capacity = 1;  _data = new int[_capacity]; return true;}
  if(is_full()){
    _capacity = 2*_size;
    int* new_data = new int[_capacity];
    for(int i=0; i< _size; i++){
      *(new_data + i) = *(_data + i);
    }
    if(_data != nullptr){
      delete[] _data;
    }
    _data = new_data;
    return true;
  }
  if(_size != 0 && _capacity == 2*_size){return false;}
  return false;
}

void mini_vector::push_back(int element){
  if(_size == _capacity){
    this->resize();
  }
  *(_data + _size++) = element;

}

void mini_vector::pop_back(){
  *(_data + _size--) = 0;
}

void mini_vector::erase(int index){
  if(index == 0 || index <= 0){std::cout << "Erase index cannot be or less than zero!!"<<std::endl;return;}
  if(index > _size){std::cout << "Out of bound error!!!!"<<std::endl;return;}
  if(index == _size){this->pop_back();return;}
  for(int i=index-1; i< _size; i++){
    *(_data + i) = *(_data + i + 1);
  }
  _size--;
}

void mini_vector::erase(int start_index, int end_index){
  int temp = start_index;
  if(start_index == 0 || start_index <= 0){std::cout << "start index Erase index cannot be or less than zero!!"<<std::endl;return;}
  if(end_index == 0 || end_index <= 0){std::cout << "end index Erase index cannot be or less than zero!!"<<std::endl;return;}
  if(start_index > _size || end_index > _size){std::cout << "Out of bound error!!!!"<<std::endl;return;}
  if(start_index == end_index){this->erase(temp);}
  for(int i=start_index; i<=end_index; i++){
    this->erase(temp);
  }

  /*more optimized version
  for(int i=start_index; i< _size; i++){
    *(_data + i) = *(_data + end_index +1);
  }
  _size = _size - (end_index - start_index);
  */
}


void mini_vector::remove(int element){
  if(!this->count(element)){
    std::cout << "Couln't found element in mini_vector." << std::endl;
    return;
  }
  for(int i=0; i< _size; i++){
    if((*(_data + i)) == element){
      this->erase(i+1);
      return;
    }
  }
}

void mini_vector::remove_all(int element){
  if(!this->count(element)){
      std::cout << "Couln't found element in mini_vector." << std::endl;
      return;
    }
  int loop = this->count(element);
  for(int i=0; i< loop; i++){
    this->remove(element);
  }
}

void mini_vector::clear(){
  for(int i=0; i<_size; i++){
    *(_data + i) = 0;
  }
}


void mini_vector::delete_vec(){
  if(_data != nullptr){
    delete[] _data;
    _data = nullptr;
  }
  _size = 0;
  _capacity = 0;
}


int mini_vector::count(int element) const{
  int count =0;
  for(int i=0; i<_size; i++){
    if(*(_data+i) == element){
      count++;
    }
  }
  return count;
}

void mini_vector::insert_at(int element, int index){
  if(index > _size || index <= 0){
    std::cout << "Erro out of bound!!" << std::endl;
    return;
  }
  *(_data + (index - 1)) = element;
}

int mini_vector::size() const{ return _size;}
int mini_vector::max_size() const{ return _capacity;}
int mini_vector::capacity() const{return _capacity;}
int mini_vector::front() const{ return *(_data);}
int mini_vector::back() const{ return *(_data + (_size-1));}
int mini_vector::at(int index) const{
  if(index > _size || index <= 0){
    std::cout << "At operation :Error out of bound!!" << std::endl;
    return 0;
  }
  return *(_data + index - 1);

}


int* mini_vector::iterator(int index){
  if(index > _size || index < 0){
    std::cout << "iteraotr : Error out of bound!!" << std::endl;
    return _data;
  }
  return (_data + (index-1));
}
int* mini_vector::begin(){
  return this->iterator(1);
}
int* mini_vector::end(){
  return this->iterator(_size);
}

bool mini_vector::is_empty() const{
  return (_size == 0);
}

bool mini_vector::is_full() const{
  return (_size == _capacity);
}

const int& mini_vector::operator[](int index) const{
  if(index > _size || index < 0){
    std::cout << "const []operator :Error out of bound!!" << std::endl;
    return *_data;
  }
  return *(_data + (index-1));
}

int& mini_vector::operator[](int index){
  if(index > _size || index < 0){
    std::cout << "[]operator: Error out of bound!!" << std::endl;
    return *_data;
  }
  return *(_data + (index-1));
}

void mini_vector::print() const{
  if(_size == 0){
    std::cout << "Empty vector" << std::endl;
    return;
  }
  for(int i=1; i<= _size; i++){
    std::cout << this->at(i) << ' ';
  }
  std::cout << std::endl;
}



void print_vector(const mini_vector& vec){
  vec.print();
}
