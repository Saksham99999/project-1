#ifndef HASH_TABLE_H
#define HASH_TABLE_H

#include <iostream>
#include <string>
#include "mini_vector.h"

using namespace std;

struct Node{
    bool isString;
    int intKey;
    string strKey;
    int value;
};

class HashTable{

private:
    int capacity;
    mini_vector* table;

    int midSquareHash(int key);
    unsigned int adler32(string key);

public:

    HashTable(int size=10);
    ~HashTable();

    void insert(int key,int value);
    void insert(string key,int value);

    void print();
};

#endif
