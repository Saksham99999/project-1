#include "hash_table.h"

HashTable::HashTable(int size){
    capacity = size;
    table = new mini_vector[capacity];
}

HashTable::~HashTable(){
    delete[] table;
}

int HashTable::midSquareHash(int key){

    long square = key * key;

    string s = to_string(square);

    int mid = s.length()/2;

    int middle = stoi(s.substr(mid-1,2));

    return middle % capacity;
}

unsigned int HashTable::adler32(string key){

    const int MOD = 65521;

    unsigned int A = 1;
    unsigned int B = 0;

    for(char c : key){
        A = (A + c) % MOD;
        B = (B + A) % MOD;
    }

    return (B << 16) | A;
}

void HashTable::insert(int key,int value){

    int index = midSquareHash(key);

    table[index].push_back(value);
}

void HashTable::insert(string key,int value){

    unsigned int hash = adler32(key);

    int index = hash % capacity;

    table[index].push_back(value);
}

void HashTable::print(){

    for(int i=0;i<capacity;i++){

        cout<<"Index "<<i<<": ";

        for(int j=1;j<=table[i].size();j++){
            cout<<table[i].at(j)<<" ";
        }

        cout<<endl;
    }
}
