#ifndef MINI_VECTOR_H
#define MINI_VECTOR_H

#define size_t unsigned long


class mini_vector{
private:
  int* _data;
  size_t _size;
  size_t _capacity;
  bool resize();
public:
  mini_vector();
  mini_vector(size_t size);
  mini_vector(int *data, size_t size);
  mini_vector(int *data, size_t size, size_t capacity);

  //using rule of 3
  ~mini_vector();
  mini_vector(const mini_vector& other);
  mini_vector& operator=(const mini_vector& other);

  void push_back(int element);
  void pop_back();
  void erase(int index);
  void erase(int start_index, int end_index);
  void remove(int element);
  void remove_all(int element);
  void clear();
  void insert_at(int element, int index);
  void delete_vec();

  int count(int element) const;
  int size() const;
  int max_size() const;
  int capacity() const;
  int front() const;
  int back() const;
  int at(int index) const;

  int* iterator(int index=0);
  int* begin();
  int* end();

  bool is_empty() const;
  bool is_full() const;

  const int& operator[](int index) const;
  int& operator[](int index);


  void print() const;

};


void print_vector(const mini_vector& vec);




#endif
